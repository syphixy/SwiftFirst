import SwiftUI

/*let checkThis = { (param: Int) -> Bool in
    let check = 5
    let checkIt = 5 > param ? true : false
    return checkIt
}
checkThis(6)*/
//TUTORIAL DAY 9
/*let sayHello = { (name: String) -> String in
    "Hi \(name)"
    
}
sayHello("JOhn")
*/
/*let team = ["Ada", "Sam", "Stren", "Nick"]
let teamSorted = team.sorted()
print(teamSorted)

func captainOneSorted(name1: String, name2: String) -> Bool {
    if name1 == "Ada" {
            return true
    }
    else if name2 == "Ada" {
            return false
    }
    return name1 < name2
    
}

//let captainOneTeam = team.sorted(by: captainOneSorted)
//print(captainOneTeam)
 
 
 
 
 
let captainFirstTeam = team.sorted(by: { (name1: String, name2: String) -> Bool in
    if name1 == "Ada" {
            return true
    }
    else if name2 == "Ada" {
            return false
    }
    return name1 < name2
})
print(captainFirstTeam)

 
 
 
 

//TRAILING CLOSURES AND SHORTHAND

let captainFirstrTeam = team.sorted {
    if $0 == "Ada" {
            return true
    }
    else if $1 == "Ada" {
            return false
    }
    return $0 < $1
}
print(captainFirstrTeam)

let reverseTeam = team.sorted {$0 > $1}

let tOnly = team.filter { $0.hasPrefix("A") }
print(tOnly)
 
let mapCheck = team.map { $0.uppercased()}
print(mapCheck)
*/
 
 
 
//HOW TO ACCEPT FUNCTIONS AS PARAMETERS
/*func makeArr( size: Int, using generator: () -> Int) -> [Int] {
    var numbers = [Int]()
    for x in 1..<size {
        let newNum = generator()
        numbers.append(newNum)
    }
    return numbers
}

func doImportantWork(first: () -> Void, second: () -> Void, third: () -> Void) {
    print("About to start first")
    first()
    print("About to start second")
    second()
    print("About to start second")
    third()
    print("Done")
}

doImportantWork {
    print("This is the first work")
}
second: {
    print("This is the second work")
}
third: {
    print("This is the third work")
}
*/


//CHECKPOINT 5
//1 VARIANT
/*let luckynumbers = [7, 4, 38, 21, 16, 15, 12, 33, 31, 49]

let luckySort = luckynumbers.sorted(by: <)
    
let filterCheck = luckynumbers.filter( { $0 % 2 == 0})

for x in luckySort {
    print("\(x) is a lucky number")
}
for x in luckySort {
    print("\(x)\n")
}
// 2 VARIANT
let luckyNumbers = [7,4,38,21,16,15,12,33,31,49]
print(luckyNumbers.filter{!$0.isMultiple(of: 2)}.sorted().map{print("\($0) is a lucky number")})

let user = 10

let check = user == 10 ? "There are ten of them" : "More than ten"
print(check)
*/

// 1 FEBRUARY, CLOSURES + DAY 10
/*let sayHI = { ( name: String) -> Bool in
    var checkString = name == "Hello" ? true : false
    return checkString
}
//CLOSURE CALL WITH PARAMETER
var resultCheck = sayHI("hello")
print("Check result \(resultCheck)")



//STRUCT
struct Employee {
    let name: String
    var vacationRemaigning: Int
    
    mutating func takeVacation(days: Int) {
        if vacationRemaigning > days {
            vacationRemaigning -= days
            print("I'm going on vacation!")
            print("Days remaigning: \(vacationRemaigning)")
        }
        else {
            print("Ooops! There aren't enough days remaigning")
        }
        
    }
}
var archer = Employee(name: "Sterling", vacationRemaigning: 34)
archer.takeVacation(days: 5)
print(archer.vacationRemaigning)

let kane = Employee(name: "Lana Kane", vacationRemaigning: 5)
let jessy = Employee(name: "Jessy Rhoades", vacationRemaigning: 17)
//COMPUTED PROPERTY
struct EmployeeTwo {
    let name: String
    var vacationaAllocated = 14
    var vacationTaken = 0
    
    var vacationRemaigning: Int {
        get {
            vacationaAllocated - vacationTaken
        }
        set {
            vacationaAllocated = vacationTaken + newValue
        }
    }
}

var steff = EmployeeTwo(name: "Steff", vacationaAllocated: 17)
steff.vacationTaken += 4
steff.vacationRemaigning = 5
print(steff.vacationaAllocated)

// my code - needs improvement
struct Football {
    var teamOne = 0
    var teamTwo = 0
    var goalDiff = 0
    var findWinner: Int {
        get {
            var check = teamOne - teamTwo
            let findDiff = check > 0 ? teamOne : teamTwo
        }
        set {
            goalDiff = teamOne + newValue
        }
        
    }
}
var validation = Football(teamOne = 6, teamTwo = 5)
validation.teamOne += 3
validation.goalDiff += 4
print(goalDiff)
*/
//3 FEBRUARY
//numbers.map( { number: String})


//HOW TO TAKE ACTION WHEN A PROPERTY CHANGES
/*struct App {
    var contacts = [String]() {
        willSet {
            print("Current value is: \(contacts)")
            print("New value will be: \(newValue)")
        }
        didSet {
            print("There are now \(contacts.count) contacts")
            print("Old value was: \(oldValue)")
        }
    }
}
var app = App()
app.contacts.append("John")
app.contacts.append("Melly")
app.contacts.append("Tam")
*/
//4 FEBRUARY
//RETURN 0 FOR ODD NUMBERS CLOSURES PRACTICE
/*var arr = [6,5,7,17,2,5,7,20,25]
let check = arr.map({ (x: Int) -> Int in
    return x.isMultiple(of: 2) ? x : 0
    
})
print(arr)
print(check)
//COUNT HOW MANY 7S ARE IN ARRAY
let arrSeven = { (seven: [Int]) -> Int in
    let checkSeven =  {
        let checkIt = $0 == 7 ? true : false
        return checkIt
    }
}
//NORMAL VERSION
func count7(_ input: [Int]) -> Int {
    var count = 0
    
    for num in input {
        if num == 7 {
            count += 1
        }
    }
    return count
}
 */
//PROGRAM TO CHECK FIRST 4 NUMBERS IN AN ARRAY, ARRAY COULD CONTAIN LESS THAN 4 ITEMS
/*let arrCheck = {(x: [(Int)] -> Bool)
    guard x.count > 3 else {
        return false
    }
    if x.prefix(4).contains(7) {
        return true
    }
    else {
        return false
    }
    }
arrCheck([5])
*/
// 5 FEBRUARY
/*func arrayFront(_ input: [Int]) -> Bool {
    guard input.count > 3 else {
        return false
    }
    
    if input.prefix(4).contains(7) {
        return true
    }
    return false
}
print(arrayFront([6,5,4,17]))
*/
//CUSTOM INITIALIZERS
/*struct Player {
    let name: String
    let number: Int
    
    init(name: String, number: Int) {
        self.name = name
  //      number = Int.random(in: 1...99)
    }
}
let player = Player(name: "Johny G")
print(player.number)
*/
// 6 FEBRUARY DAY 11 ACCESS CONTROL |
                            //
/*struct BankAccount {
    private(set) var funds = 0
    
    mutating func deposit(amount: Int) {
        funds += amount
    }
    
    mutating func withdraw(amount: Int) -> Bool {
        if funds >= amount {
            funds -= amount
            return true
        }
        else {
            return false
        }
    }
}
var account = BankAccount()
account.deposit(amount: 1200)
let success = account.withdraw(amount: 200)

if success {
    print("Withdrew money - correct")
}
else {
    print("Failed due to the overlimit")
}
//STATIC PROPERTIES AND METHODS
struct School {
    static var studentCount = 0
    
    static func add(student: String) {
        print("\(student) joined the school.")
        studentCount += 1
    }
}

School.add(student:  "John")
print(School.studentCount)

struct AppData {
    static let version = "1.3 beta 2"
    static let saveFileName = "Settings.json"
    static let homeURL = "https://www.richtsem.com"
}

struct Employee {
    let username: String
    let password: String
    
    static let example = Employee(username: "Syphixy", password: "ASdasklfjsadkl;fj")
}
*/
//CHECKPOINT 6
struct Car {
    let model: String
    let numberSeats: Int
    public var gear = 1
    enum Gear {
        case up, down, neutral
    }
    public mutating func changeGear(_ direction: Gear){
        switch direction {
        case .down: gear -= 1
            if gear < 1 {gear = 1}
        case .up: gear += 1
            if gear > 10 {gear = 10}
        case .neutral:
            gear = 1
        }
        print("The \(model) is in gear \(gear)")
    }
}
var test = Car(model: "Audi", numberSeats: 5, gear: 1)
test.changeGear(.up)
test.changeGear(.down)
test.changeGear(.neutral)
